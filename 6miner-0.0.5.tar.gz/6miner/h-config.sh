conf="-a hns/bl2bsha3 -o ${CUSTOM_URL} -u ${CUSTOM_TEMPLATE} -p ${CUSTOM_PASS} --no-color ${CUSTOM_USER_CONFIG}"
echo "$conf" > $CUSTOM_CONFIG_FILENAME
